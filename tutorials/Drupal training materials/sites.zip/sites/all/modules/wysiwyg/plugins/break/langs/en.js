
tinyMCE.addToLang('break', {
  title: 'Insert teaser break',
  desc: 'Separate teaser and body of this content'
});

