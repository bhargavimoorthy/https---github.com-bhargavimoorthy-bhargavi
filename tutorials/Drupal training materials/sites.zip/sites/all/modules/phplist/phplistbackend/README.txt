Installation of PHPlistbackend
------------------------------

How it works
------------
This module makes use of the PHPlist token which allows the embedding of a web page in a newsletter.

    [URL:http://mysite/mypage]

Thus the page in question will appear in the email, fully rendered as per your site, with no effort on your part :)


How to use it
-------------
Enable the module as per any other module and then edit the content types that you wish to send via PHPlist.  You'll see an extra 
option in the "Publishing Options" tab to "send as newsletter".  Once checked, new content of this type will have extra fields to
allow it to be used as the source of PHPlist messages.