
This is where the reCAPTCHA PHP library lives.

The library is available at the following URL:
http://code.google.com/p/recaptcha/downloads/list?q=label:phplib-Latest
