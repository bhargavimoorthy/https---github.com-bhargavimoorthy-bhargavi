<?php

/**
 * @file
 * Contains \Drupal\first_module\Controller\FirstModuleController.
 */

namespace Drupal\first_module\Controller;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Controller routines for page example routes.
 */
class FirstModuleController {
  /**
   * Constructs a simple page.
   *
   * The router _content callback, maps the path 'examples/first_module/simple'
   * to this method.
   *
   * _content callbacks return a renderable array for the content area of the
   * page. The theme system will later render and surround the content with the
   * appropriate blocks, navigation, and styling.
   */
  public function simple() {
    return array(
      '#markup' => '<p>' . t('Hi This is my fist hook_menu.') . '</p>',
    );
  }
}
